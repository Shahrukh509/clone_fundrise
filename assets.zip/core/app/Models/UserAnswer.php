<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserAnswer extends Model
{
    use HasFactory;


    protected $fillable = ['user_id','questionaire_id','questionaire_answer_id'];

    public function hasAccountType()
    {
        return $this->hasOne(QuestionaireAnswer::class, 'id', 'questionaire_answer_id');
    }


}
